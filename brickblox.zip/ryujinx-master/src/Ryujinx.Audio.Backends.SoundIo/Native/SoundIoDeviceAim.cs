namespace Ryujinx.Audio.Backends.SoundIo.Native
{
    public enum SoundIoDeviceAim
    {
        SoundIoDeviceAimInput = 0,
        SoundIoDeviceAimOutput = 1,
    }
}
