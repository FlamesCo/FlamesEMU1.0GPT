
namespace ARMeilleure.CodeGen.Arm64
{
    enum ArmShiftType
    {
        Lsl = 0,
        Lsr = 1,
        Asr = 2,
        Ror = 3,
    }
}
