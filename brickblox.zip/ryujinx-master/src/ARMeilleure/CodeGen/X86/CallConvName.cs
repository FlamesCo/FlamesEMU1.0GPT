namespace ARMeilleure.CodeGen.X86
{
    enum CallConvName
    {
        SystemV,
        Windows,
    }
}
