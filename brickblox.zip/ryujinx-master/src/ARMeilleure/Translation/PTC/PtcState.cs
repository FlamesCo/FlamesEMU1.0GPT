namespace ARMeilleure.Translation.PTC
{
    enum PtcState
    {
        Enabled,
        Continuing,
        Closing,
        Disabled,
    }
}
