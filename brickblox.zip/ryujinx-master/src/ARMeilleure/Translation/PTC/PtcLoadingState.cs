namespace ARMeilleure.Translation.PTC
{
    public enum PtcLoadingState
    {
        Start,
        Loading,
        Loaded,
    }
}
