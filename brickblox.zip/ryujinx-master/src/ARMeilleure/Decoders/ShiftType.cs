namespace ARMeilleure.Decoders
{
    enum ShiftType
    {
        Lsl = 0,
        Lsr = 1,
        Asr = 2,
        Ror = 3,
    }
}
