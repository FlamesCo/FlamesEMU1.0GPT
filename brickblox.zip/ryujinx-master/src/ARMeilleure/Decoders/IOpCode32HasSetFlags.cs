namespace ARMeilleure.Decoders
{
    interface IOpCode32HasSetFlags
    {
        bool? SetFlags { get; }
    }
}
