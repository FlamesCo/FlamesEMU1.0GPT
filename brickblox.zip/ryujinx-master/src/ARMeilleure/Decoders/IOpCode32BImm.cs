namespace ARMeilleure.Decoders
{
    interface IOpCode32BImm : IOpCode32, IOpCodeBImm { }
}
