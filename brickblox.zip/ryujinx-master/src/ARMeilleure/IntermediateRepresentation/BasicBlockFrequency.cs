namespace ARMeilleure.IntermediateRepresentation
{
    enum BasicBlockFrequency
    {
        Default,
        Cold,
    }
}
