namespace ARMeilleure.IntermediateRepresentation
{
    enum RegisterType
    {
        Integer,
        Vector,
        Flag,
        FpFlag,
    }
}
